┍━━━━━━━━━★━━━━━━━━━┑
 ┬ ┬ ┌─┐ ┬   ┬   ┌─┐
 ├─┤ ├┤  │   │   │ │
 ┴ ┴ └─┘ ┴─┘ ┴─┘ └─┘
┕━━━━━━━━━★━━━━━━━━━┙                               
                                      
This interior furniture asset pack was released on itch.io by MariaIsMe and is licensed under Attribution 4.0 International (CC BY 4.0). For more information regarding this license, visit this link: https://creativecommons.org/licenses/by/4.0/ 
 
Featured in this asset pack are the obj files of the following furniture objects:

Chairs (13 Chairs, 3 Couches, 2 Pillow Pieces)
Tables (10 Tables, 9 Side Tables,  6 Coffee Tables, 18 Table Pieces)
Beds (6 Singles, 2 Doubles)
Misc (2 Windows, 1 Door, 1 Floor, 1 Wall, 2 Clocks, 2 Closets, 2 Shelves, 6 Plants, 2 Door Pieces) 

To make or customize your own tables, check out the fragments folder for easier editing.

I'd love to see what you come up with this asset pack! Share your work by tagging me on twitter ( https://twitter.com/EggnCheesePls ) or instagram ( https://www.instagram.com/alyanna.maramag/ )
If you have any questions or requests, let me know!


Thanks for downloading! 


♡ Maria
